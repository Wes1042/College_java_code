// A simple program demonstrating String objects.

public class StringDemo
{
   public static void main(String[] args)
   {
      String greeting = "Good morning, ";
      String name = "Herman";

      System.out.println(greeting + name);
   }
}
