// Another well adjusted printing program

public class Tabs
{
   public static void main(String[] args)
   {
      System.out.print("These are our top sellers:\n");
      System.out.print("\tComputer games\n\tCoffee\n ");
      System.out.println("\tAspirin");
   }
}
